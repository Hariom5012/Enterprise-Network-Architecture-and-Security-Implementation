# Enterprise-Network-Architecture-and-Security-Implementation
Enterprise network infrastructure design using VLANs, OSPF, DHCP, DNS, NAT, ACLs, SSH, Syslog, and network services in Cisco Packet Tracer.

## Project Overview

This project demonstrates the design and implementation of a secure enterprise network infrastructure using Cisco Packet Tracer. The network includes a Head Office, Branch A, and Branch B connected using OSPF dynamic routing. It also includes VLAN segmentation, Inter-VLAN Routing, DHCP, DNS, Web Server, NAT, ACL-based security, SSH management, and Syslog monitoring.

## Technologies Used

- Cisco Packet Tracer
- VLANs
- Inter-VLAN Routing
- OSPF
- DHCP
- DNS
- Web Server
- ACLs
- SSH
- NAT
- Syslog Server
- Site-to-Site VPN Design

## Network Design

The network is divided into multiple departments using VLANs:

| VLAN | Department | Network |
|---|---|---|
| VLAN 10 | HR | 192.168.10.0/24 |
| VLAN 20 | Finance | 192.168.20.0/24 |
| VLAN 30 | IT | 192.168.30.0/24 |
| VLAN 40 | Servers | 192.168.40.0/24 |
| VLAN 99 | Management | 192.168.99.0/24 |

Branch networks:

| Location | Network |
|---|---|
| Branch A | 192.168.110.0/24 |
| Branch B | 192.168.120.0/24 |

## Features Implemented

### 1. VLAN Segmentation
Created VLANs for HR, Finance, IT, Servers, and Management to separate departments and improve network security.

### 2. Inter-VLAN Routing
Configured router-on-a-stick to allow communication between different VLANs.

### 3. OSPF Routing
Implemented OSPF dynamic routing between Head Office, Branch A, and Branch B.

### 4. DHCP Services
Configured DHCP pools for automatic IP address assignment.

### 5. DNS Services
Configured DNS records for:
- company.local
- intranet.company.local

### 6. Web Server
Hosted a simple internal company website.

### 7. ACL Security
Configured ACL rules to restrict HR from accessing the Finance network while allowing IT full access.

### 8. SSH Management
Enabled SSH for secure remote management of routers and switches.

### 9. NAT
Configured NAT overload/PAT to provide internet access to internal networks.

### 10. Site-to-Site VPN Design
Designed secure site-to-site VPN connectivity between HQ and branch networks.

### 11. Syslog Monitoring
Configured Syslog server to collect logs from network devices.

## Security Policies

| Policy | Description |
|---|---|
| HR to Finance | Blocked |
| IT to All Departments | Allowed |
| SSH | Enabled for secure management |
| NAT | Enabled for internet access |
| Syslog | Enabled for monitoring |

## Testing Performed

- VLAN verification using `show vlan brief`
- Trunk verification using `show interfaces trunk`
- Inter-VLAN ping test
- DHCP automatic IP assignment test
- DNS resolution test
- Web server access test
- ACL blocked access test
- SSH remote login test
- OSPF neighbor verification
- NAT translation verification
- Syslog monitoring test

## Screenshots

Screenshots are available in the `Screenshots` folder.

## Conclusion

This project helped me gain practical experience in enterprise network design, routing, switching, network security, service deployment, and troubleshooting. It demonstrates core skills required for networking, cybersecurity, and infrastructure-related roles.
